create procedure p1(IN a1 int, IN a2 int, INOUT a3 int, OUT a4 int)
BEGIN
	DECLARE temp1 int;
	DECLARE temp2 int default 0;
	set temp1=0;
	set a4=temp1+temp2+a1+a2;
	set a3=a3+100;
END;

